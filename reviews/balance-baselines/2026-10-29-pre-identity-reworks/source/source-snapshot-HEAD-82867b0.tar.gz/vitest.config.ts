import { defineConfig } from 'vitest/config';

export default defineConfig({
  test: {
    include: ['packages/*/src/**/*.test.ts', 'tools/**/*.test.ts', 'apps/*/src/**/*.test.ts'],
    environment: 'node',
  },
});
