import { describe, expect, it } from 'vitest';
import { RIFTWALKERS } from '@sr/content/v2';
import {
  RATING_START,
  carryOver,
  cleanRank,
  cleanReplay,
  rankOf,
  rateMatch,
  seasonAt,
  seasonOf,
} from './index';

describe('Arena ranks', () => {
  it('start everyone in Bronze II, and climb through the divisions to Diamond', () => {
    expect(rankOf(RATING_START).label).toBe('Bronze II');
    expect(rankOf(900).label).toBe('Bronze III');
    expect(rankOf(1099).label).toBe('Bronze I');
    expect(rankOf(1100).label).toBe('Silver III');
    expect(rankOf(1249).label).toBe('Silver I');
    expect(rankOf(1250).label).toBe('Gold III');
    expect(rankOf(1400).label).toBe('Platinum III');
    expect(rankOf(1549).label).toBe('Platinum I');
    expect(rankOf(1550).label).toBe('Diamond');
    expect(rankOf(2400)).toMatchObject({ name: 'Diamond', next: null });
  });

  it('say how far through a division a rating is', () => {
    const r = rankOf(1125);
    expect(r.next).toBe(1150);
    expect(r.progress).toBeCloseTo(0.5);
  });

  it('move a rating further for beating someone rated higher, and further in the first games', () => {
    const even = rateMatch({ rating: 1000, games: 20 }, { rating: 1000, games: 20 });
    expect(even.winner).toBe(1012);
    expect(even.loser).toBe(988);
    const upset = rateMatch({ rating: 1000, games: 20 }, { rating: 1300, games: 20 });
    expect(upset.winner - 1000).toBeGreaterThan(12);
    const fresh = rateMatch({ rating: 1000, games: 0 }, { rating: 1000, games: 0 });
    expect(fresh.winner - 1000).toBeGreaterThan(even.winner - 1000);
    // a sure thing still moves a little
    const sure = rateMatch({ rating: 2400, games: 50 }, { rating: 600, games: 50 });
    expect(sure.winner).toBeGreaterThan(2400);
    expect(sure.loser).toBeLessThan(600);
  });

  it('pull ratings halfway back to the start at a new season', () => {
    expect(carryOver(1600)).toBe(1300);
    expect(carryOver(800)).toBe(900);
    expect(carryOver(RATING_START)).toBe(RATING_START);
  });

  it('take only a well-formed badge from the wire', () => {
    expect(cleanRank({ rating: 1200, games: 4 })).toEqual({ rating: 1200, games: 4 });
    expect(cleanRank({ rating: 1.5, games: 4 })).toBeUndefined();
    expect(cleanRank({ rating: 1200 })).toBeUndefined();
    expect(cleanRank('gold')).toBeUndefined();
  });
});

describe('seasons', () => {
  it('are months of the Arena board, named for the month', () => {
    // 2026-10-15 12:00 UTC
    const mid = Date.UTC(2026, 9, 15, 12);
    const s = seasonAt(mid);
    expect(s.key).toBe('2026-10');
    expect(s.name).toBe('October 2026');
    expect(s.id).toBe(seasonOf(mid));
    expect(s.ends).toBeGreaterThan(mid);
    expect(seasonAt(s.ends).key).toBe('2026-11');
    // the first of the month, early in UTC, is still the last day of the month before in Pacific time
    expect(seasonAt(Date.UTC(2026, 10, 1, 3)).key).toBe('2026-10');
  });
});

describe('replays', () => {
  const entry = {
    name: 'Ann',
    hero: 'knight',
    deck: [...RIFTWALKERS.knight.starter],
    boons: [],
    tier: 4,
  };
  const good = {
    id: 'AbCdEfGh23',
    at: 1,
    rules: 2,
    seed: 'x',
    a: entry,
    b: { ...entry, name: 'Bo' },
    log: [{ seat: 'a', action: { type: 'endTurn' } }],
    winner: 'a',
    reason: 'resign',
    game: 2,
  };
  it('are read back when well-formed', () => {
    const r = cleanReplay(good);
    expect(r?.a.name).toBe('Ann');
    expect(r?.log).toHaveLength(1);
    expect(r?.game).toBe(2);
  });
  it('a game the clock called can be watched again, and each move keeps its fingerprint', () => {
    expect(cleanReplay({ ...good, reason: 'time' })?.reason).toBe('time');
    const hashed = cleanReplay({
      ...good,
      log: [{ seat: 'a', action: { type: 'endTurn' }, hash: 'abc123' }],
    });
    expect(hashed?.log[0]?.hash).toBe('abc123');
    // (older replays without fingerprints still load)
    expect(cleanReplay(good)?.log[0]?.hash).toBeUndefined();
  });
  it('are refused when anything in them is off', () => {
    expect(cleanReplay({ ...good, id: 'short' })).toBeNull();
    expect(cleanReplay({ ...good, winner: 'c' })).toBeNull();
    expect(cleanReplay({ ...good, log: [{ seat: 'c', action: { type: 'endTurn' } }] })).toBeNull();
    expect(cleanReplay({ ...good, log: [{ seat: 'a', action: { type: 'cheat' } }] })).toBeNull();
    expect(cleanReplay({ ...good, a: { ...entry, deck: ['nope'] } })).toBeNull();
  });
});
