import { describe, expect, it } from 'vitest';
import { applyAction, chooseAction, createCombat, seedRng, heroOf } from '@sr/combat';
import { COMBAT_DB, RIFTWALKERS, encounter, type HeroId } from '@sr/content/v2';
import {
  DECK_RULES,
  FINAL_STAGE,
  RunError,
  availableNodes,
  bank,
  buyCard,
  buyRemoval,
  buyUpgrade,
  upgradePrice,
  canAdd,
  chooseCard,
  chooseEvent,
  pickEventCard,
  pickDeckCard,
  choosePrelude,
  continueLoop,
  duelPlan,
  enterNode,
  finishDuel,
  floorsOf,
  generateStageMap,
  DIFFICULTY,
  EVENT_FIGHT_ODDS,
  enemyScale,
  leaveMerchant,
  newRun,
  nextStage,
  offerCards,
  parseRun,
  reachableNodes,
  realmOfStage,
  serializeRun,
  takeShrine,
  upgradable,
  type RunState,
  type StageRealm,
} from './index';
import { giftOffers } from './rewards';

/** Most tests are about the map and what is on it: step past the opening choice without taking anything from it. */
const open = (r: RunState): RunState => ({ ...r, phase: 'map', context: null });
const fresh = (h: HeroId, seed: string, d: 'easy' | 'normal' = 'normal'): RunState =>
  open(newRun(h, seed, d));

const HEROES = Object.keys(RIFTWALKERS) as HeroId[];

describe('stage maps', () => {
  it('every stage map from many seeds is well formed and every node can reach the Warden', () => {
    for (let seed = 0; seed < 100; seed++) {
      for (const [stage, realm] of [
        [1, 'aurelion'],
        [2, 'nexus'],
        [3, 'wyldmaw'],
        [4, 'umbral'],
      ] as [number, StageRealm][]) {
        const map = generateStageMap(seedRng(`m${seed}`), stage, realm);
        const ids = new Set(map.nodes.map((n) => n.id));
        expect(ids.size).toBe(map.nodes.length);
        const warden = map.nodes.find((n) => n.kind === 'warden');
        expect(warden?.enemyId).toBeTruthy();
        const f1 = map.nodes.filter((n) => n.floor === 1);
        expect(f1.length).toBeGreaterThanOrEqual(2);
        expect(f1.every((n) => n.kind === 'duel')).toBe(true);
        expect(map.nodes.filter((n) => n.kind === 'elite').every((n) => n.floor >= 3)).toBe(true);
        for (const n of map.nodes) {
          for (const t of n.next) {
            expect(ids.has(t)).toBe(true);
            expect(map.nodes.find((m) => m.id === t)?.floor).toBe(n.floor + 1);
          }
          if (n.kind !== 'warden') expect(n.next.length).toBeGreaterThan(0);
        }
        const reach = new Set(f1.map((n) => n.id));
        for (let f = 1; f <= map.floors; f++)
          for (const n of map.nodes.filter((x) => x.floor === f && reach.has(x.id)))
            n.next.forEach((t) => reach.add(t));
        expect(reach.size).toBe(map.nodes.length);
      }
    }
  });

  it('never puts more than two Events in a row on any path', () => {
    for (let seed = 0; seed < 300; seed++) {
      const map = generateStageMap(seedRng(`ev${seed}`), 1 + (seed % 4), 'nexus');
      const longest = new Map<string, number>();
      for (let f = 1; f <= map.floors; f++)
        for (const n of map.nodes.filter((x) => x.floor === f)) {
          const here = n.kind === 'event' ? (longest.get(n.id) ?? 0) + 1 : 0;
          expect(here, n.id).toBeLessThanOrEqual(2);
          for (const t of n.next) longest.set(t, Math.max(longest.get(t) ?? 0, here));
        }
    }
  });

  it('every fight node names a real encounter of the right realm', () => {
    const map = generateStageMap(seedRng('enc'), 2, 'nexus');
    for (const n of map.nodes.filter((x) => x.enemyId)) expect(n.enemyId).toBeTruthy();
    expect(map.nodes.find((n) => n.kind === 'warden')?.enemyId).toBe('kron');
  });

  it('a run is three stages: seven floors and a Warden, twice, then the Rift of eight floors and Vorthax', () => {
    expect(FINAL_STAGE).toBe(3);
    const first = generateStageMap(seedRng('x'), 1, 'nexus');
    expect(first.floors).toBe(floorsOf(1) + 1);
    expect(first.nodes.find((n) => n.kind === 'warden')?.enemyId).toBe('kron');
    const map = generateStageMap(seedRng('x'), FINAL_STAGE, 'rift', undefined, [
      'umbral',
      'wyldmaw',
    ]);
    expect(map.floors).toBe(floorsOf(FINAL_STAGE) + 1);
    // no path ever has two Merchants in a row
    for (let s = 0; s < 150; s++)
      for (const stage of [1, 2, FINAL_STAGE]) {
        const m = generateStageMap(
          seedRng(`merch-${s}`),
          stage,
          stage >= FINAL_STAGE ? 'rift' : 'aurelion',
        );
        for (const n of m.nodes)
          if (n.kind === 'merchant')
            for (const id of n.next)
              expect(m.nodes.find((x) => x.id === id)?.kind, `${n.id} -> ${id}`).not.toBe(
                'merchant',
              );
      }
    // the last stop before a Warden is always a Shrine, on every stage and every map
    for (let s = 0; s < 150; s++)
      for (const stage of [1, 2, FINAL_STAGE]) {
        const m = generateStageMap(
          seedRng(`last-${s}`),
          stage,
          stage >= FINAL_STAGE ? 'rift' : 'aurelion',
        );
        const last = m.nodes.filter((n) => n.floor === floorsOf(stage));
        expect(last.length).toBeGreaterThan(0);
        expect(
          last.every((n) => n.kind === 'shrine'),
          `seed ${s} stage ${stage}`,
        ).toBe(true);
        // ...and a Merchant is still to be found somewhere before it
        expect(
          m.nodes.some((n) => n.kind === 'merchant'),
          `seed ${s} stage ${stage}`,
        ).toBe(true);
      }
    expect(map.nodes.find((n) => n.kind === 'warden')?.enemyId).toBe('vorthax');
    // its fights come only from the two realms the run has not visited
    const realms = new Set(
      map.nodes
        .filter((n) => n.kind === 'duel' || n.kind === 'elite')
        .map((n) => encounter(n.enemyId as string).realm),
    );
    for (const r of realms) expect(['umbral', 'wyldmaw']).toContain(r);
  });

  it('every run visits four realms: two as stages, two in the Rift', () => {
    const run = newRun('knight', 'realms');
    expect(new Set(run.stageRealms).size).toBe(4);
    expect(realmOfStage(run, 1)).toBe(run.stageRealms[0]);
    expect(realmOfStage(run, 2)).toBe(run.stageRealms[1]);
    expect(realmOfStage(run, 3)).toBe('rift');
  });

  it('is deterministic per seed', () => {
    expect(generateStageMap(seedRng('same'), 1, 'nexus')).toEqual(
      generateStageMap(seedRng('same'), 1, 'nexus'),
    );
  });
});

describe('rewards', () => {
  it('never offer a card the deck cannot take, and offer distinct cards', () => {
    for (const h of HEROES) {
      const run = fresh(h, 'r');
      for (let i = 0; i < 80; i++) {
        const offers = offerCards(seedRng(`o${i}`), h, run.deck, i % 2 ? 'elite' : 'duel', 3);
        expect(offers).toHaveLength(3);
        expect(new Set(offers).size).toBe(3);
        for (const id of offers) {
          expect(COMBAT_DB.cards[id]).toBeDefined();
          expect(canAdd(run.deck, id)).toBe(true);
        }
      }
    }
  });
  it('takes at most 5 copies of a card, basics too (DECISIONS #337)', () => {
    expect(canAdd(['rift-bolt', 'rift-bolt', 'rift-bolt', 'rift-bolt'], 'rift-bolt')).toBe(true);
    expect(canAdd(['strike', 'strike', 'strike', 'strike'], 'strike')).toBe(true);
    expect(canAdd(['strike', 'strike', 'strike', 'strike', 'strike'], 'strike')).toBe(false);
  });
});

describe('the run', () => {
  it('starts as designed', () => {
    for (const h of HEROES) {
      const r = fresh(h, 's');
      expect(r.deck).toEqual(RIFTWALKERS[h].starter);
      expect(r.hp).toBe(RIFTWALKERS[h].hero.maxHp);
      expect(r.resolve).toBe(2);
      expect(r.phase).toBe('map');
      expect(availableNodes(r).every((n) => n.floor === 1)).toBe(true);
    }
  });

  it('normal is the default; easy has weaker enemies, more Resolve and some shards; hard has less Resolve', () => {
    expect(newRun('knight', 'default-diff').difficulty).toBe('normal');
    const e = open(newRun('knight', 'easy', 'easy'));
    expect(e.difficulty).toBe('easy');
    expect(e.resolve).toBe(5);
    expect(e.shards).toBe(100);
    // Easy is Normal's Tier I stage 1 (whatever the tier table says) times Easy's ratio to Normal
    // (read from the table, so tuning the table never breaks this)
    const t1 = enemyScale(1, 1);
    expect(duelPlan(enterNode(e, availableNodes(e)[0]!.id))).toMatchObject({
      hpPct: Math.round((DIFFICULTY.easy.hpPct / DIFFICULTY.normal.hpPct) * t1.hp),
      dmgPct: Math.round((DIFFICULTY.easy.dmgPct / DIFFICULTY.normal.dmgPct) * t1.dmg),
    });
    expect(newRun('knight', 'hard', 'hard').resolve).toBe(1);
    expect(parseRun(JSON.stringify({ ...e, difficulty: undefined }))?.difficulty).toBe('easy');
    expect(parseRun(JSON.stringify({ ...e, difficulty: 'brutal' }))).toBeNull();
  });

  it('is the same run for the same seed and never mutates what it is given', () => {
    const a = fresh('hunter', 'seed-1');
    const snapshot = JSON.stringify(a);
    enterNode(a, availableNodes(a)[0]!.id);
    expect(JSON.stringify(a)).toBe(snapshot);
    expect(JSON.stringify(fresh('hunter', 'seed-1'))).toBe(snapshot);
  });

  it('rejects things the rules forbid', () => {
    const r = fresh('engineer', 's');
    expect(() => enterNode(r, 'nope')).toThrow(RunError);
    expect(() => finishDuel(r, true, 10)).toThrow(RunError);
    expect(() => chooseCard(r, null)).toThrow(RunError);
    expect(() => nextStage(r)).toThrow(RunError);
    const inFight = enterNode(r, availableNodes(r)[0]!.id);
    expect(inFight.phase).toBe('duel');
    expect(duelPlan(inFight)?.deck).toHaveLength(10);
    expect(() => finishDuel(inFight, true, 0)).toThrow(RunError); // dead heroes do not win
    expect(() => finishDuel(inFight, true, 99999)).toThrow(RunError);
  });

  it('HP carries over after a win, and a loss costs Resolve but not HP', () => {
    let r = enterNode(fresh('knight', 'hp'), availableNodes(fresh('knight', 'hp'))[0]!.id);
    const lost = finishDuel(r, false);
    expect(lost.resolve).toBe(1);
    expect(lost.hp).toBe(r.hp);
    expect(lost.phase).toBe('duel');
    expect(duelPlan(lost)?.seed).not.toBe(duelPlan(r)?.seed); // a different shuffle on retry
    r = finishDuel(lost, true, 51);
    expect(r.hp).toBe(51);
    expect(r.phase).toBe('reward');
    expect(r.shards).toBe(15);
  });

  it('max HP gained in a fight (Bloodfeast) is kept for good, and cannot be made up', () => {
    const r = enterNode(fresh('knight', 'maxhp'), availableNodes(fresh('knight', 'maxhp'))[0]!.id);
    const max = r.maxHp;
    const won = finishDuel(r, true, max + 3, undefined, 3);
    expect(won.maxHp).toBe(max + 3);
    expect(won.hp).toBe(max + 3);
    // HP above the new maximum, or an absurd gain, is refused
    expect(() => finishDuel(r, true, max + 4, undefined, 3)).toThrow(RunError);
    expect(() => finishDuel(r, true, max, undefined, 999)).toThrow(RunError);
    expect(() => finishDuel(r, true, max, undefined, -1)).toThrow(RunError);
  });

  it('collapses at 0 Resolve', () => {
    let r = enterNode(fresh('trickster', 'c'), availableNodes(fresh('trickster', 'c'))[0]!.id);
    for (let i = 0; i < 2; i++) r = finishDuel(r, false);
    expect(r.phase).toBe('collapsed');
  });

  it('shrines rest, upgrade and remove', () => {
    const base = fresh('knight', 'shr');
    const shrineRun = (): RunState => ({
      ...base,
      hp: 30,
      phase: 'shrine',
      at: 'x',
      context: { nodeId: base.map.nodes[0]!.id },
    });
    const rested = takeShrine(shrineRun(), { kind: 'rest' });
    expect(rested.hp).toBe(30 + Math.ceil(RIFTWALKERS.knight.hero.maxHp * 0.35));
    const up = takeShrine(shrineRun(), { kind: 'upgrade', card: 'sundering-blow' });
    expect(up.deck).toContain('sundering-blow+');
    expect(up.deck).not.toContain('sundering-blow');
    expect(upgradable(up.deck)).not.toContain('sundering-blow+');
    expect(() => takeShrine(shrineRun(), { kind: 'upgrade', card: 'rift-bolt' })).toThrow(RunError);
    const small = { ...shrineRun(), deck: base.deck.slice(0, DECK_RULES.minSize) };
    expect(() => takeShrine(small, { kind: 'remove', card: 'strike' })).toThrow(RunError);
    expect(takeShrine(shrineRun(), { kind: 'remove', card: 'strike' }).deck).toHaveLength(9);
  });

  it('save and load round-trips, and damaged saves are refused', () => {
    const r = fresh('engineer', 'save');
    expect(parseRun(serializeRun(r))).toEqual(r);
    expect(parseRun('not json')).toBeNull();
    expect(parseRun(JSON.stringify({ ...r, v: 1 }))).toBeNull();
    expect(parseRun(JSON.stringify({ ...r, hp: 0 }))).toBeNull();
    expect(parseRun(JSON.stringify({ ...r, deck: ['nope', ...r.deck] }))).toBeNull();
    expect(parseRun(JSON.stringify({ ...r, character: 'zed' }))).toBeNull();
  });
});

/** Play a whole run with the greedy bot: fight everything, take the first reward, rest at shrines. */
function botRun(hero: HeroId, seed: string): { run: RunState; fights: number } {
  let run = fresh(hero, seed, 'easy');
  let fights = 0;
  for (let step = 0; step < 400; step++) {
    switch (run.phase) {
      case 'map': {
        const n = availableNodes(run);
        run = enterNode(run, n[0]!.id);
        break;
      }
      case 'duel': {
        const plan = duelPlan(run)!;
        fights++;
        let { state } = createCombat(COMBAT_DB, {
          seed: plan.seed,
          a: { hero, deck: plan.deck, hp: plan.hp, boons: plan.boons },
          b: { enemies: plan.units, tier: plan.tier },
        });
        for (let i = 0; i < 800 && !state.winner; i++)
          state = applyAction(COMBAT_DB, state, chooseAction(COMBAT_DB, state)).state;
        const hp = heroOf(state.sides.a)?.hp ?? 0;
        run = state.winner === 'a' ? finishDuel(run, true, hp) : finishDuel(run, false);
        break;
      }
      case 'reward':
        run = chooseCard(run, run.context!.offers![0]!);
        break;
      case 'gift':
        run = chooseCard(run, run.context!.offers![0]!);
        break;
      case 'shrine':
        run = takeShrine(run, { kind: 'rest' });
        break;
      case 'merchant':
        run = leaveMerchant(run);
        break;
      case 'event':
        // (an event may be waiting for a card to be picked from three)
        run = run.context!.event!.choose
          ? pickEventCard(run, 0)
          : run.context!.event!.chooseDeck
            ? pickDeckCard(run, run.context!.event!.chooseDeck.cards[0]!)
            : chooseEvent(run, run.context!.event!.options.find((o) => o.id !== 'trial')!.id);
        break;
      case 'prelude':
        run = choosePrelude(run, run.context!.prelude!.options[0]!.id);
        break;
      case 'stageClear':
        run = nextStage(run);
        break;
      case 'loopCleared':
        return { run: bank(run), fights };
      default:
        return { run, fights };
    }
  }
  return { run, fights };
}

describe('a whole run, played by the bot', () => {
  it('always ends banked or collapsed and never throws', () => {
    for (const h of HEROES) {
      const { run, fights } = botRun(h, `bot-${h}`);
      expect(['banked', 'collapsed']).toContain(run.phase);
      expect(fights).toBeGreaterThan(3);
      expect(run.hp).toBeGreaterThan(0);
      expect(parseRun(serializeRun(run))).not.toBeNull();
    }
  });

  it('reachableNodes agrees with availableNodes at the start', () => {
    const r = fresh('knight', 'z');
    expect(reachableNodes(r.map, null, []).map((n) => n.id)).toEqual(
      availableNodes(r).map((n) => n.id),
    );
  });

  it('continuing a loop raises the tier and heals', () => {
    const r = { ...fresh('knight', 'loop'), phase: 'loopCleared' as const, hp: 10 };
    const c = continueLoop(r);
    expect(c.tier).toBe(2);
    expect(c.hp).toBe(c.maxHp);
    expect(c.stage).toBe(1);
  });

  it('Rift Tier 20 is the last: you can only bank there', () => {
    const r = { ...fresh('knight', 'cap'), phase: 'loopCleared' as const, tier: 20 };
    expect(() => continueLoop(r)).toThrow(RunError);
    expect(continueLoop({ ...r, tier: 19 }).tier).toBe(20);
  });
});

describe('the other rooms and the rules around them', () => {
  const at = (run: RunState, phase: RunState['phase'], context: RunState['context']): RunState => ({
    ...run,
    phase,
    at: run.map.nodes[0]!.id,
    context,
  });
  const nodeId = (r: RunState) => r.map.nodes[0]!.id;

  it('the merchant sells cards and one removal, and refuses what you cannot afford', () => {
    const base = fresh('knight', 'shop');
    const card = offerCards(seedRng('shop'), 'knight', base.deck, 'duel', 1)[0]!;
    const shop = (shards: number): RunState => ({
      ...at(base, 'merchant', {
        nodeId: nodeId(base),
        merchant: {
          items: [{ cardId: card, price: 50, sold: false }],
          removePrice: 40,
          removed: false,
        },
      }),
      shards,
    });
    expect(() => buyCard(shop(10), 0)).toThrow(RunError);
    const bought = buyCard(shop(80), 0);
    expect(bought.deck).toContain(card);
    expect(bought.shards).toBe(30);
    expect(() => buyCard(bought, 0)).toThrow(RunError); // sold
    const removed = buyRemoval(shop(80), 'strike');
    expect(removed.deck).toHaveLength(9);
    expect(removed.shards).toBe(40);
    expect(() => buyRemoval(removed, 'strike')).toThrow(RunError); // one per visit
    expect(leaveMerchant(shop(0)).phase).toBe('map');
  });

  it('the merchant upgrades a card, each upgrade at that shop costs more, and the next shop starts over', () => {
    const base = fresh('knight', 'shop-up');
    const shop = (shards: number): RunState => ({
      ...at(base, 'merchant', {
        nodeId: nodeId(base),
        merchant: { items: [], removePrice: 40, removed: false },
      }),
      shards,
    });
    const card = base.deck.find((id) => !!COMBAT_DB.cards[id]?.upgrade) as string;
    const up = COMBAT_DB.cards[card]?.upgrade as string;
    expect(upgradePrice(0)).toBeLessThan(upgradePrice(1));
    expect(upgradePrice(1)).toBeLessThan(upgradePrice(2));
    expect(() => buyUpgrade(shop(upgradePrice(0) - 1), card)).toThrow(RunError); // too poor
    expect(() => buyUpgrade(shop(500), 'not-a-card')).toThrow(RunError);
    expect(() => buyUpgrade(shop(500), up)).toThrow(RunError); // already upgraded
    const first = buyUpgrade(shop(1000), card);
    expect(first.shards).toBe(1000 - upgradePrice(0));
    expect(first.deck).toContain(up);
    expect(first.deck.filter((id) => id === card)).toHaveLength(
      base.deck.filter((id) => id === card).length - 1,
    );
    expect(first.context?.merchant?.upgrades).toBe(1);
    // the second one at this shop is dearer
    const other = first.deck.find((id) => !!COMBAT_DB.cards[id]?.upgrade) as string;
    const second = buyUpgrade(first, other);
    expect(second.shards).toBe(first.shards - upgradePrice(1));
    expect(second.context?.merchant?.upgrades).toBe(2);
    // a fresh shop is back to the base price (and a shop saved by an older build counts none)
    expect(buyUpgrade(shop(1000), card).shards).toBe(1000 - upgradePrice(0));
    expect(() => buyUpgrade({ ...base, phase: 'map' }, card)).toThrow(RunError);
  });

  describe('an Event stop that is a fight instead', () => {
    // a stop on the given floor turned into an Event (as if the earlier stops had been cleared), then entered
    const enterEvent = (seed: string, floor: number): RunState => {
      const run = fresh('knight', seed);
      // walk down the first path to the floor before, and call everything above it cleared
      let at = availableNodes(run)[0]!;
      for (let f = 1; f < floor; f++) at = run.map.nodes.find((n) => n.id === at.next[0])!;
      const node = run.map.nodes.find((n) => n.id === at.id)!;
      const before = floor > 1 ? run.map.nodes.find((n) => n.next.includes(at.id))! : null;
      run.cleared = run.map.nodes.filter((n) => n.floor < floor).map((n) => n.id);
      run.at = before?.id ?? null;
      node.kind = 'event';
      delete node.enemyId;
      return enterNode(run, node.id);
    };

    it(
      'turns into a plain fight now and then, played and rewarded like any other',
      { timeout: 60000 },
      () => {
        // (nothing happens to an event stood on the first floor, which real maps never have)
        for (let i = 0; i < 40; i++) expect(enterEvent(`first${i}`, 1).phase).toBe('event');
        let ambushes = 0;
        const N = 400;
        for (let i = 0; i < N; i++) {
          const r = enterEvent(`amb${i}`, 2);
          if (r.phase === 'duel') {
            ambushes++;
            const node = r.map.nodes.find((n) => n.id === r.context?.nodeId)!;
            expect(node.kind).toBe('duel'); // (an Elite waits for the third floor)
            expect(node.enemyId).toBeTruthy();
            expect(r.eventResult).toMatch(/^Ambush!/);
            expect(duelPlan(r)?.encounterId).toBe(node.enemyId);
          } else expect(r.phase).toBe('event');
        }
        const pct = (ambushes / N) * 100;
        expect(pct).toBeGreaterThan(EVENT_FIGHT_ODDS.duel + EVENT_FIGHT_ODDS.elite - 8);
        expect(pct).toBeLessThan(EVENT_FIGHT_ODDS.duel + EVENT_FIGHT_ODDS.elite + 8);
      },
    );

    it(
      'is sometimes an Elite from the third floor on, and winning it pays like an Elite',
      { timeout: 60000 },
      () => {
        let elite: RunState | null = null;
        for (let i = 0; i < 1500 && !elite; i++) {
          const r = enterEvent(`elite${i}`, 3);
          if (r.phase === 'duel' && duelPlan(r)?.kind === 'elite') elite = r;
        }
        expect(elite).not.toBeNull();
        expect(elite!.eventResult).toMatch(/Elite/);
        const won = finishDuel(elite!, true, 10);
        expect(won.phase).toBe('reward');
        expect(won.context?.nodeId).toBe(elite!.context!.nodeId);
      },
    );

    it('losing the ambush costs Resolve and retries the same fight', () => {
      let fight: RunState | null = null;
      for (let i = 0; i < 600 && !fight; i++) {
        const r = enterEvent(`lose${i}`, 2);
        if (r.phase === 'duel') fight = r;
      }
      expect(fight).not.toBeNull();
      const lost = finishDuel(fight!, false);
      expect(lost.resolve).toBe(fight!.resolve - 1);
      expect(lost.phase).toBe('duel');
      expect(duelPlan(lost)?.encounterId).toBe(duelPlan(fight!)?.encounterId);
    });

    it('survives being saved and loaded in the middle of the fight', () => {
      let fight: RunState | null = null;
      for (let i = 0; i < 600 && !fight; i++) {
        const r = enterEvent(`save${i}`, 2);
        if (r.phase === 'duel') fight = r;
      }
      const back = parseRun(serializeRun(fight!));
      expect(back).not.toBeNull();
      expect(duelPlan(back!)?.encounterId).toBe(duelPlan(fight!)?.encounterId);
    });
  });

  it('events pay shards, heal, give the card, or do nothing', () => {
    const base = { ...fresh('engineer', 'ev'), hp: 20 };
    const ev = at(base, 'event', {
      nodeId: nodeId(base),
      event: {
        title: 't',
        text: 't',
        cardOffer: 'rift-bolt',
        options: [
          { id: 'shards', label: 's' },
          { id: 'heal', label: 'h' },
          { id: 'card', label: 'c' },
          { id: 'leave', label: 'l' },
        ],
      },
    });
    expect(chooseEvent(ev, 'shards').shards).toBe(40);
    expect(chooseEvent(ev, 'heal').hp).toBe(20 + Math.ceil(RIFTWALKERS.engineer.hero.maxHp * 0.2));
    expect(chooseEvent(ev, 'card').deck).toContain('rift-bolt');
    expect(chooseEvent(ev, 'leave').phase).toBe('map');
  });

  it("a Warden win heals, restores Resolve and offers your class's rare cards, which can be skipped", () => {
    const base = fresh('knight', 'boss');
    const wardenNode = base.map.nodes.find((n) => n.kind === 'warden')!;
    const run: RunState = {
      ...base,
      hp: 20,
      resolve: 1,
      phase: 'duel',
      at: wardenNode.id,
      context: { nodeId: wardenNode.id },
    };
    const won = finishDuel(run, true, 20);
    expect(won.phase).toBe('gift');
    expect(won.hp).toBeGreaterThanOrEqual(20 + Math.floor(RIFTWALKERS.knight.hero.maxHp * 0.3)); // a Warden falls: you catch your breath (a boon may add more)
    expect(won.resolve).toBe(2);
    expect(
      won.context!.offers!.every(
        (id) =>
          ['rare', 'legendary'].includes(COMBAT_DB.cards[id]?.rarity ?? '') &&
          COMBAT_DB.cards[id]?.hero === 'knight',
      ),
    ).toBe(true);
    const skipped = chooseCard(won, null);
    expect(skipped.phase).toBe('stageClear');
    expect(skipped.deck).toEqual(won.deck);
    const picked = chooseCard(won, won.context!.offers![0]!);
    expect(picked.phase).toBe('stageClear');
    expect(nextStage(picked).stage).toBe(2);
  });

  it('the last Warden leaves its Gift too, and then the loop is cleared (DECISIONS #352)', () => {
    const base = { ...fresh('knight', 'final-boss'), stage: FINAL_STAGE };
    const wardenNode = base.map.nodes.find((n) => n.kind === 'warden')!;
    const run: RunState = {
      ...base,
      phase: 'duel',
      at: wardenNode.id,
      context: { nodeId: wardenNode.id },
    };
    const won = finishDuel(run, true, 30);
    expect(won.phase).toBe('gift');
    expect(won.context!.offers!.length).toBeGreaterThanOrEqual(3);
    expect(chooseCard(won, null).phase).toBe('loopCleared');
    const picked = chooseCard(won, won.context!.offers![0]!);
    expect(picked.phase).toBe('loopCleared');
    expect(picked.deck).toContain(won.context!.offers![0]);
  });

  it("a Warden's Gift always has cards: with every rare at its copy limit, the next rarity down fills it (DECISIONS #352)", () => {
    const rares = Object.values(COMBAT_DB.cards)
      .filter((c) => c.hero === 'knight' && c.rarity === 'rare' && !c.id.endsWith('+') && !c.source)
      .map((c) => c.id);
    const deck = rares.flatMap((id) => Array<string>(5).fill(id));
    const offers = giftOffers(seedRng('gift-full'), 'knight', deck, 3);
    expect(offers).toHaveLength(3);
    expect(offers.every((id) => COMBAT_DB.cards[id]?.rarity !== 'rare')).toBe(true);
  });

  it('elites heal a little, losing an elite costs 2 Resolve', () => {
    const base = fresh('knight', 'elite');
    const el = base.map.nodes.find((n) => n.kind === 'elite');
    if (!el) return; // this seed's stage 1 has no elite
    const run: RunState = { ...base, hp: 40, phase: 'duel', at: el.id, context: { nodeId: el.id } };
    expect(finishDuel(run, true, 40).hp).toBe(40 + Math.ceil(base.maxHp * 0.1));
    expect(finishDuel(run, false).resolve).toBe(0);
  });

  it('the 5-copy cap counts a card and its upgrade together (DECISIONS #337)', () => {
    expect(canAdd(['rift-bolt', 'rift-bolt+', 'rift-bolt+', 'rift-bolt'], 'rift-bolt')).toBe(true);
    expect(
      canAdd(['rift-bolt', 'rift-bolt+', 'rift-bolt+', 'rift-bolt', 'rift-bolt+'], 'rift-bolt'),
    ).toBe(false);
  });

  it('a save cannot smuggle in prototype keys', () => {
    const r = fresh('knight', 'proto');
    expect(parseRun(JSON.stringify({ ...r, character: 'constructor' }))).toBeNull();
    expect(parseRun(JSON.stringify({ ...r, deck: ['toString', ...r.deck] }))).toBeNull();
  });

  it('Bank ends the run with the deck, Continue goes a tier deeper', () => {
    const cleared: RunState = { ...fresh('trickster', 'end'), phase: 'loopCleared' };
    expect(bank(cleared).phase).toBe('banked');
    expect(continueLoop(cleared).tier).toBe(2);
    expect(() => bank(fresh('trickster', 'end'))).toThrow(RunError);
  });
});

describe('the heal after a won fight (DECISIONS #285, removed from Kesh in #333)', () => {
  it('the Hunter heals 2 after a won fight (DECISIONS #381); the others do not', () => {
    const won = (hero: HeroId): number => {
      const base = fresh(hero, 'trait-heal');
      const node = base.map.nodes.find((n) => n.kind === 'duel')!;
      const run: RunState = {
        ...base,
        hp: 40,
        phase: 'duel',
        at: node.id,
        context: { nodeId: node.id },
      };
      return finishDuel(run, true, 40).hp;
    };
    expect(won('hunter')).toBe(42);
    expect(won('knight')).toBe(40);
  });
});
