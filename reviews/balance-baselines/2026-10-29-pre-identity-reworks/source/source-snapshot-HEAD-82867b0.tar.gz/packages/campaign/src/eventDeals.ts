// The data-driven events: each is a title, a few sentences and a list of options, every option a list of DealSteps (deals.ts).
// An event is only offered when every option can be taken right now, so none can be unplayable. Labels read "Headline (price): reward".

import { clone } from '@sr/combat';
import { dealFeasible, nameRemovals, pinRemovals, type EventCtx } from './deals';
import { offerBoon } from './rewards';
import type { EventDef } from './events';
import type { DealStep, EventOption, RunState } from './types';

/** An option; the fourth part 'optional' means it is left off when it cannot be taken now (instead of the event not being offered). */
export type OptSpec = [label: string, steps: DealStep[], say?: string, optional?: 'optional'];

export interface DealSpec {
  id: string;
  weight: number;
  title: string;
  text: string;
  /** the event offers a Boon (and is not offered when you own them all) */
  boon?: boolean;
  /** no "walk away" option: every choice is a real one */
  noLeave?: boolean;
  opts: OptSpec[];
  /** only when this is true of the run (a stage, a class, a flag, a state of health) */
  needs?: (r: RunState) => boolean;
  /** options that depend on the run (cards named when the event is built); they replace opts and may lay cards on the table */
  dyn?: (r: RunState) => { opts: OptSpec[]; cards?: string[] };
}

export const hurt = (n: number): DealStep => ({ k: 'hurt', n });
export const hurtPct = (n: number): DealStep => ({ k: 'hurtPct', n });
export const heal = (pct: number): DealStep => ({ k: 'heal', pct });
export const maxHp = (n: number): DealStep => ({ k: 'maxHp', n });
export const shards = (n: number): DealStep => ({ k: 'shards', n });
export const wound = (n = 1): DealStep => ({ k: 'wound', n });
export const potion = (n = 1): DealStep => ({ k: 'potion', n });
export const boon: DealStep = { k: 'boon' };
export const upgrade = (n = 1): DealStep => ({ k: 'upgrade', n });
export const remove = (of: 'wound' | 'basic' | 'any', n = 1): DealStep => ({ k: 'remove', of, n });
export const transform: DealStep = { k: 'transform' };
export const copy: DealStep = { k: 'copy' };
export const gift = (rarity: 'common' | 'uncommon' | 'rare'): DealStep => ({ k: 'gift', rarity });
export const chance = (pct: number, win: DealStep[], lose: DealStep[] = []): DealStep => ({
  k: 'chance',
  pct,
  win,
  lose,
});

/** Build the event for this run (the Boon, if any, is picked here) and its options. */
export function make(spec: DealSpec, r: RunState): EventCtx {
  const boonOffer = spec.boon ? (offerBoon(r.rng, r.boons, 'elite') ?? '') : '';
  const built = spec.dyn ? spec.dyn(r) : { opts: spec.opts, cards: undefined };
  // (an optional option that cannot be taken now is left off)
  const probe = clone(r);
  const shown = built.opts.filter(
    ([, deal, , optional]) =>
      optional !== 'optional' ||
      dealFeasible(probe, deal, { title: '', text: '', cardOffer: '', options: [] }),
  );
  // a random removal picks its card now, and the option says which (DECISIONS #233)
  const options: EventOption[] = shown.map(([label, deal, say], i) => {
    const pinned = pinRemovals(r, deal);
    return {
      id: (['d1', 'd2', 'd3', 'd4'] as const)[i] as EventOption['id'],
      label: nameRemovals(label, pinned.names),
      deal: pinned.steps,
      ...(pinned.shows.lose.length || pinned.shows.gain.length ? { shows: pinned.shows } : {}),
      ...(say ? { say } : {}),
    };
  });
  if (!spec.noLeave) options.push({ id: 'leave', label: 'Walk away' });
  return {
    title: spec.title,
    text: spec.text,
    options,
    cardOffer: '',
    ...(built.cards?.length ? { cardOffers: built.cards } : {}),
    ...(boonOffer ? { boonOffer } : {}),
  };
}

export function def(spec: DealSpec): EventDef {
  return {
    id: spec.id,
    weight: spec.weight,
    // offered only when every option works (on a copy, so the real run's dice are untouched)
    when: (r) => {
      if (spec.needs && !spec.needs(r)) return false;
      const probe = clone(r);
      const ev = make(spec, probe);
      if (spec.boon && !ev.boonOffer) return false;
      // a table of cards that came up empty is not an event
      if (spec.dyn && !ev.options.some((o) => o.deal)) return false;
      return ev.options.every((o) => !o.deal || dealFeasible(probe, o.deal, ev));
    },
    build: (r) => make(spec, r),
  };
}

export const DEAL_EVENTS: EventDef[] = (
  [
    {
      id: 'ferry',
      weight: 1.2,
      title: 'The drowned ferry',
      text: 'A ferryman stands waist-deep in black water, pole in hand. The far bank is only a rope-length away.',
      opts: [
        [
          'Pay the fare (30 shards): heal 40% of your HP',
          [shards(-30), heal(40)],
          'You ride in silence.',
        ],
        [
          'Wade across (lose 8 HP): find 60 shards',
          [hurt(8), shards(60)],
          'The current pulls, and the mud gives something up.',
        ],
        [
          'Pay with a card (a random basic card leaves): heal 25% and +25 shards',
          [remove('basic'), heal(25), shards(25)],
          'The ferryman weighs it in his palm and nods.',
          'optional',
        ],
      ],
    },
    {
      id: 'hourglass',
      weight: 1,
      title: 'The cracked hourglass',
      text: 'An hourglass taller than you, its sand falling upward. Whoever holds it owns a little time.',
      opts: [
        [
          'Turn it (lose 6 HP): you take a random potion',
          [hurt(6), potion()],
          'The sand reverses.',
        ],
        [
          'Shatter it (an even chance): two random cards in your deck are upgraded, or a Wound is added to it',
          [chance(50, [upgrade(2)], [wound()])],
          'The glass goes everywhere.',
        ],
        [
          'Feed it a card (a random basic card leaves): you take a random potion',
          [remove('basic'), potion()],
          'The sand pours out in a bottle.',
          'optional',
        ],
      ],
    },
    {
      id: 'silent-choir',
      weight: 1,
      title: 'The silent choir',
      text: 'Robed figures stand in rows with their mouths open. No sound comes out, and still the air shakes.',
      opts: [
        ['Listen: +3 max HP', [maxHp(3)], 'The silence settles in your chest.'],
        [
          'Join in (lose 10 HP): a random uncommon card of your class joins your deck',
          [hurt(10), gift('uncommon')],
          'You open your mouth, and something answers.',
        ],
        [
          'Sing a card away (a random basic card leaves): heal 15% of your HP',
          [remove('basic'), heal(15)],
          'It is gone, and nothing is lost.',
          'optional',
        ],
      ],
    },
    {
      id: 'beggar',
      weight: 1.2,
      title: 'The rift beggar',
      text: 'A beggar sits on a crate of broken glass, hand out. Their eyes are far too clever.',
      opts: [
        [
          'Give a little (25 shards): a random common card of your class is added to your deck',
          [shards(-25), gift('common')],
        ],
        [
          'Give a lot (60 shards): a random uncommon card of your class is added to your deck',
          [shards(-60), gift('uncommon')],
        ],
        [
          'Give a card instead (a random basic card leaves): a random common card of your class is added to your deck',
          [remove('basic'), gift('common')],
          'The beggar nods as if it were a fair trade.',
          'optional',
        ],
      ],
    },
    {
      id: 'scales',
      weight: 1,
      title: 'The weighing scales',
      text: 'Brass scales hang from a gibbet, one pan heavy with coin, the other empty. "Balance what you carry."',
      opts: [
        ['Take the coin (a Wound joins your deck): +115 shards', [wound(), shards(115)]],
        [
          'Lighten your load (pay 40 shards): a Wound leaves your deck, or a basic card if you have none',
          [shards(-40), remove('wound', 1)],
        ],
      ],
    },
    {
      id: 'reliquary',
      weight: 1,
      title: 'The locked reliquary',
      text: 'A stone casket bound in chain and wax. Something inside has been waiting a long time.',
      boon: true,
      opts: [
        ['Break it open (lose 14 HP): you gain the Boon', [hurt(14), boon]],
        [
          'Pick the lock (an even chance): the Boon, or two Wounds',
          [chance(50, [boon], [wound(2)])],
        ],
      ],
    },
    {
      id: 'hungry-door',
      weight: 1,
      title: 'The hungry door',
      text: 'A door with a mouth where the handle should be. It looks at your pockets and licks its lip.',
      opts: [
        [
          'Feed it a basic card (a random Strike or Defend goes): +80 shards and heal 10%',
          [remove('basic', 1), shards(80), heal(10)],
        ],
        [
          'Feed it your shards (50 shards): a random card in your deck is upgraded',
          [shards(-50), upgrade()],
        ],
      ],
    },
    {
      id: 'wagon',
      weight: 1.2,
      title: "The tinker's wagon",
      text: 'A wagon hung with bottles, and a tinker who has stopped asking where the road goes.',
      opts: [
        ['Buy one potion (35 shards): you take a random potion', [shards(-35), potion(1)]],
        ['Buy two potions (60 shards): you take two random potions', [shards(-60), potion(2)]],
        [
          'Trade a card (a random basic card leaves): you take a random potion',
          [remove('basic'), potion()],
          'The tinker does not even look at it.',
          'optional',
        ],
      ],
    },
    {
      id: 'crossroads',
      weight: 1.2,
      title: 'The lamplit crossroads',
      text: 'Three roads under three lamps. The left one is loud, the right one is quiet, and the middle one has footprints.',
      opts: [
        [
          'Take the left road (an even chance): +115 shards, or lose 15% of your HP',
          [chance(50, [shards(115)], [hurtPct(15)])],
        ],
        ['Take the right road: heal 20% of your HP', [heal(20)]],
        [
          'Follow the footprints: a random common card of your class is added to your deck',
          [gift('common')],
        ],
        [
          'Leave a card at the crossroads (a random basic card leaves): +40 shards and heal 10%',
          [remove('basic'), shards(40), heal(10)],
          'Travellers have left things here for longer than anyone remembers.',
          'optional',
        ],
      ],
    },
    {
      id: 'echo-vault',
      weight: 1,
      title: 'The echoing vault',
      text: 'A round chamber where every sound comes back changed. In the middle, a stand holds one card, face down.',
      opts: [
        [
          'Take it (an even chance): a random rare card of your class joins your deck, or lose 20% of your HP and a Wound joins your deck',
          [chance(50, [gift('rare')], [hurtPct(20), wound()])],
        ],
      ],
    },
    {
      id: 'mud-sworn',
      weight: 1,
      title: 'The mud-sworn',
      text: 'A figure made of river-clay blocks the path, arms spread. It wants to wrestle, or to be paid.',
      opts: [
        [
          'Wrestle it (lose 12 HP): +105 shards',
          [hurt(12), shards(105)],
          'It crumbles, and its pockets are full.',
        ],
        ['Bargain (pay 30 shards): you take a random potion', [shards(-30), potion()]],
        [
          'Bury a card in the clay (a random basic card leaves): +50 shards',
          [remove('basic'), shards(50)],
          'It sinks, and the clay hands back coin.',
          'optional',
        ],
      ],
    },
    {
      id: 'geyser',
      weight: 1,
      title: 'The shard geyser',
      text: 'Hot spray full of glittering shards leaps from a vent in the floor, every few breaths.',
      opts: [
        ['Fill your pockets (lose 6 HP): +70 shards', [hurt(6), shards(70)]],
        ['Stand in it (lose 20% of your HP): +170 shards', [hurtPct(20), shards(170)]],
        [
          'Seal a card in the vent (a random basic card leaves): +45 shards',
          [remove('basic'), shards(45)],
          'The vent coughs, and spits coin.',
          'optional',
        ],
      ],
    },
    {
      id: 'gravedigger',
      weight: 1,
      title: 'The gravedigger',
      text: 'A man leans on a spade beside a half-dug hole. "Dig, if you like. They keep their own counsel."',
      opts: [
        [
          'Dig (lose 8 HP): +105 shards, or a Wound in the bargain',
          [hurt(8), chance(60, [shards(105)], [wound()])],
        ],
        ['Pay your respects: heal 10% of your HP', [heal(10)]],
        [
          'Bury a card (a random basic card leaves): heal 10% and +40 shards',
          [remove('basic'), heal(10), shards(40)],
          'He tips his cap and fills the hole.',
          'optional',
        ],
      ],
    },
    {
      id: 'rust-eater',
      weight: 1,
      title: 'The rust-eater',
      text: 'A beast the colour of old iron gnaws a broken gate. It looks up, hopeful.',
      opts: [
        [
          'Feed it a Wound, or a basic card: it leaves your deck, and you gain 35 shards',
          [remove('wound', 1), shards(35)],
        ],
        [
          'Feed it any card: it leaves your deck, and two random cards in your deck are upgraded',
          [remove('any', 1), upgrade(2)],
        ],
      ],
    },
    {
      id: 'brewer',
      weight: 1,
      title: "The salt witch's pot",
      text: 'A pot on a driftwood fire, and a woman stirring it who does not look up. "One cup each. Choose."',
      opts: [
        ['Brew of vigor (lose 4 HP): +3 max HP', [hurt(4), maxHp(3)]],
        ['Brew of calm (pay 25 shards): heal 25% of your HP', [shards(-25), heal(25)]],
        [
          'Stir a card into the pot (a random basic card leaves): +3 max HP',
          [remove('basic'), maxHp(3)],
          'It dissolves, and she hands you a cup.',
          'optional',
        ],
      ],
    },
    {
      id: 'pact',
      weight: 1,
      title: 'The pact of the Hollow',
      text: 'A page of black paper, a quill, and a space for a name. The Hollow is generous, and it is patient.',
      boon: true,
      opts: [
        ['Sign (lose 8 max HP): you gain the Boon', [maxHp(-8), boon]],
        [
          'Sign in blood (lose 15 HP and take a Wound): you gain the Boon',
          [hurt(15), wound(), boon],
        ],
      ],
    },
    {
      id: 'purse',
      weight: 1,
      title: 'The cursed purse',
      text: 'A fat purse lies in the road, a thin red thread tied round it. Everyone before you left it there.',
      opts: [
        ['Pocket it (a Wound joins your deck): +130 shards', [wound(), shards(130)]],
        ['Cut the thread first (lose 10 HP): +130 shards', [hurt(10), shards(130)]],
      ],
    },
    {
      id: 'patient-mirror',
      weight: 1,
      title: 'The patient mirror',
      text: 'A tall mirror in an empty hall. Your reflection stands very still and does not blink.',
      opts: [
        [
          'Look closer (lose 8 HP): a random non-basic card in your deck is copied',
          [hurt(8), copy],
        ],
        [
          'Break it (an even chance): a random card in your deck is upgraded, or a Wound is added to it',
          [chance(50, [upgrade()], [wound()])],
        ],
      ],
    },
    {
      id: 'lantern-thief',
      weight: 1,
      title: 'The lantern thief',
      text: 'A small thing with a stolen lantern darts between the pillars, laughing.',
      opts: [
        ['Give chase (lose 6 HP): you take a random potion', [hurt(6), potion()]],
        [
          'Throw a coin (pay 15 shards): it leaves its lantern for you, heal 15%',
          [shards(-15), heal(15)],
        ],
        [
          'Give it a card (a random basic card leaves): +40 shards',
          [remove('basic'), shards(40)],
          'It giggles, and drops a handful of coin.',
          'optional',
        ],
      ],
    },
    {
      id: 'rift-fever',
      weight: 1,
      title: 'The rift fever',
      text: 'You wake hot and shaking in a ruined chapel. The fever will break one way or another.',
      opts: [
        ['Sweat it out (lose 10% of your HP): +4 max HP', [hurtPct(10), maxHp(4)]],
        ['Take a tonic (pay 35 shards): heal 20% of your HP', [shards(-35), heal(20)]],
        [
          'Burn out a bad memory (a random basic card leaves): heal 15% of your HP',
          [remove('basic'), heal(15)],
          'The fever breaks, and so does the habit.',
          'optional',
        ],
      ],
    },
    {
      id: 'wishing-stone',
      weight: 1,
      title: 'The wishing stone',
      text: 'A flat stone in a shallow dish of coins. A sign: "Wishes cost what they cost."',
      opts: [
        [
          'Toss a coin (pay 10 shards): a one-in-three chance that a random uncommon card of your class joins your deck',
          [shards(-10), chance(34, [gift('uncommon')])],
        ],
        [
          'Toss a handful (pay 50 shards): an even chance that a random uncommon card of your class joins your deck',
          [shards(-50), chance(50, [gift('uncommon')])],
        ],
        [
          'Toss a card in the dish (a random basic card leaves): an even chance that a random uncommon card of your class joins your deck',
          [remove('basic'), chance(50, [gift('uncommon')])],
          'The stone considers it.',
          'optional',
        ],
      ],
    },
    {
      id: 'bell-tower',
      weight: 1,
      title: 'The bell tower',
      text: 'A crooked tower with a bell as wide as a door. A rope hangs down, frayed to a thread.',
      opts: [
        [
          'Ring the bell (an even chance): +130 shards, or lose 12% of your HP',
          [chance(50, [shards(130)], [hurtPct(12)])],
        ],
        ['Muffle the bell (pay 15 shards): heal 10% of your HP', [shards(-15), heal(10)]],
        [
          'Toll the bell with a card (a random basic card leaves): +50 shards',
          [remove('basic'), shards(50)],
          'The bell rings clean, and coin falls from the rafters.',
          'optional',
        ],
      ],
    },
    {
      id: 'pilgrims',
      weight: 1,
      title: 'The pilgrims',
      text: 'A line of pilgrims carries a litter of glass bottles up the hill. One offers you a place in the line.',
      opts: [
        [
          'Carry a bottle (lose 6 HP): take a potion and +25 shards',
          [hurt(6), potion(), shards(25)],
        ],
        ['Share your supplies (pay 30 shards): heal 30% of your HP', [shards(-30), heal(30)]],
        [
          'Leave a card at the shrine on the hill (a random basic card leaves): heal 15% and +25 shards',
          [remove('basic'), heal(15), shards(25)],
          'You walk lighter.',
          'optional',
        ],
      ],
    },
  ] satisfies DealSpec[]
).map(def);
